package apps.cognifide.securecq.components.abstractTest;

public class json extends com.cognifide.securecq.sling.TestInvoker {
}
