package apps.cognifide.secureaem.components.abstractTest;

public class json extends com.cognifide.secureaem.sling.TestInvoker {
}
